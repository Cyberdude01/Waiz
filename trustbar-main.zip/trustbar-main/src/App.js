import logo from "./logo.svg";
import "./App.css";
import { Route, Switch, BrowserRouter } from "react-router-dom";
import Scantopay from "./components/scantopay";
import Success from "./components/success";
import Request from "./components/request";
import GenerateCode from "./components/generateCode";
import Home from "./components/home";
import Send2 from "./components/trustbar2";
import ScanToRequest from "./components/scantorequest";
import SigninAndCreate  from "./components/SigninAndCreate";
import Signin from "./components/Signin";
import TransferredSuccessfull from "./components/TransferredSuccessfull";
import CreateAccount from "./components/CreateAccount";
import ForgetPassword from "./components/ForgetPassword";
import AddCard from "./components/AddCard";
import Profile from "./components/profile/Profile";
import Setting from "./components/setting/Setting";
import { Chat } from "./components/chat";
function App() {
  return (
    <div>
      <Switch>
        <Route path="/scan-to-pay" component={Scantopay} exact />
        <Route path="/send2" component={Send2} />
        <Route path="/scan-to-request" component={ScanToRequest} exact />
        <Route path="/success" component={Success} exact />
        <Route path="/request" component={Request} exact />
        <Route path="/generate-code" component={GenerateCode} exact />
        <Route path="/signin-and-create" component={SigninAndCreate} exact />
        <Route path="/signin-account" component={Signin} exact />
        <Route path="/transfer-successfull" component={TransferredSuccessfull} exact />
        <Route path="/create-account" component={CreateAccount} exact />
        <Route path="/forget-password" component={ForgetPassword} exact />
        <Route path="/add-card" component={AddCard} exact />
        <Route path="/profile-update" component={Profile} exact />
        <Route path="/setting" component={Setting} exact />
        <Route path="/chat" component={Chat} exact />
        {/* <Route path="/bottom" component={Topbar} /> */}

        <Route exact path="/" component={Home} exact />
      </Switch>
    </div>
  );
}

export default App;
