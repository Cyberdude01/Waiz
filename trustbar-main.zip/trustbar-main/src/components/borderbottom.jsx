import React, { Component } from 'react'

export default class Borderbottom extends Component {
  render() {
    return (
      <div>
        <div style={{height:'5px',width:'147px',background:'#22242A',borderRadius:'100px',position:'absolute',bottom:0,left:'0',right:'0',marginLeft:'auto',marginRight:'auto',marginBottom:'5px'}}></div>
      </div>
    )
  }
}
