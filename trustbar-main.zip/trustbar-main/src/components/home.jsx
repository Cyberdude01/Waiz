import React, { Component } from "react";
import "../css/home.css";
import { GiPayMoney } from "react-icons/gi";
import { VscRequestChanges } from "react-icons/vsc";
import { BsArrowDownLeft } from "react-icons/bs";
import { FaAngleRight } from "react-icons/fa";
import { BsArrowUpRight } from "react-icons/bs";
import { Link } from "react-router-dom";
import logo from "../img/logo_mark.svg";
import { IoWalletSharp } from "react-icons/io5";
import { AiOutlineAppstoreAdd } from "react-icons/ai";
import TransHistory from "./trans-history/TransHistory";
import pay from '../img/pay.svg';
import requestMoney from '../img/requestmoney.svg'
import arrow from '../img/arrow.svg'
import BottomNav from "./bottomNav";
class Home extends Component {
  state = {};
  render() {
    return (
      <div className="home_page">
        <div className="home_header">
          <div className="logo_box">
            <img src={logo} className="header_logo"/>
          </div>
          <div className="header_content">
            <Link style={{width:'100%'}} to='/generate-code'>
            <div className="header_btn">
              <div className="btn_logo">
                  <img src={pay} className="hb_logo"/>
              </div>
              <div className="btn_info">
                <span className="info_heading">Pay</span>
                <span className="info_desc">Lorem ipsum is simply dummy text</span>
              </div>
              <div className="btn_arrow"><img src={arrow} className="hb_logo"/></div>
            </div>
            </Link >
            <Link style={{width:'100%'}} to='/request'>
            <div className="header_btn">
            <div className="btn_logo">
                  <img src={requestMoney}  className="hb_logo"/>
              </div>
              <div className="btn_info">
                <span className="info_heading">Request Money</span>
                <span className="info_desc">Lorem ipsum is simply dummy text</span>
              </div>
              <div className="btn_arrow"><img src={arrow} className="hb_logo"/></div>
            </div>
            </Link>
          </div>
        </div>
        <div className="home_body">
          <div className="balance_heading">
            <span>Balance</span>
            <span>0.00$</span>
          </div>
          <TransHistory />
        </div>
        <BottomNav/>
      </div>
    );
  }
}

export default Home;
