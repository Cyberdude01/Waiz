import { React, useState } from 'react'
import '../css/AddCard.css';
import card from '../img/card.svg';
import calender from '../img/expirydate.svg';
import { DatePicker } from 'antd';
import addDays from 'date-fns/addDays';
import add from '../img/addicon.svg';
import { Link } from 'react-router-dom';
import BottomNav from './bottomNav';
export default function AddCard() {
    const [startDate, setStartDate] = useState(null);
    const handleChangeRaw = (value) => {
        if (value === "tomorrow") {
            setStartDate(addDays(new Date(), 1));
        }
    };
    return (
        <div className='card_page'>
            <div className="card_header">
                <div className='card_holder'>
                    <img src={card} alt='image' />
                </div>
                <div className='heading_holder'>
                    Add New Card
                </div>
            </div>
            <div className='card_body'>
                <div className='card_inputcontainer'>
                    <div className='input_heading'>
                        Fill in the fields below to add a new card
                    </div>
                    <div className='card_number'>
                        <input
                            type="number"
                            id="card-number"
                            name="card-number"
                            placeholder="Place 14 digit card number"
                            className="card_input"
                        />

                    </div>
                    <div className='card_name'>
                        <div className='cinput'>
                            <input
                                type="text"
                                id="name"
                                name="name"
                                placeholder="Card holder name"
                                className="card_nameinput"
                            />
                        </div>
                        <div className='card_border'></div>
                    </div>
                    <div className='card_data'>
                        <div className='expiry_date'>
                            <div className="password_input">
                                <DatePicker
                                    selected={startDate}
                                    onChange={(date) => setStartDate(date)}
                                    placeholder='expiration date'
                                    onChangeRaw={(event) => handleChangeRaw(event.target.value)}
                                    style={{
                                        border: 'none',
                                        outline: 'none',
                                        width: '100%',
                                        height: '40px',
                                        padding: '0px !important',
                                        marginLeft: '-25px'
                                    }}
                                    className='date_picker'
                                />
                            </div>
                            <div className='card_border'></div>
                        </div>
                        <div className='divider'></div>
                        <div className='cvv'>
                            <div className="password_input">
                                <input
                                    type='text'
                                    id="cvv"
                                    name="cvv"
                                    placeholder="cvv"
                                    className="input"
                                />
                            </div>
                            <div className='card_border'></div>
                        </div>
                    </div>
                </div>
                <div className='card_btn'>
                    <Link style={{ width: '100%' }} to='/'>
                        <div className='forget_headerbtn'>

                            <div className='forget_btninfo'>
                                <span className='forget_infoheading'> <img style={{ marginRight: '9px' }} src={add} className='forget_hblogo' />Add Card</span>
                            </div>
                        </div>
                    </Link>
                </div>
                <BottomNav/>
            </div>
        </div>
    )
}
