import React , {useState} from 'react'
import "../css/bottomNav.css";
import {ReactComponent as Home} from "../img/home.svg"
import {ReactComponent as Setting} from "../img/setting.svg"
import {ReactComponent as Wallet} from "../img/wallet.svg"
import {ReactComponent as Profile} from "../img/profile.svg"
import { Link, NavLink } from 'react-router-dom';
const BottomNav = () => {
    const [active,setActive] = useState();
    const handleactive=(val)=>{
        setActive('');
        setActive(val);
        console.log('clicked')
    }
  return (
    <div className="bottom_nav">
        <NavLink exact activeClassName="active_parent" to='/'>
        <div className={`bn_item`} onClick={()=>handleactive("home")}>
        <Home stroke="#707070" className={`bn_logo ${active=="home"&&"active"}`}/>
            <span className="bn_text">Home</span>
        </div>
        </NavLink>
        <NavLink exact activeClassName="active_parent" to='/add-card'>
        <div className={`bn_item`} onClick={()=>handleactive("wallet")}>
        <Wallet stroke="#707070" className={`bn_logo`}/>
            <span  className="bn_text">Wallet</span>
        </div>
        </NavLink>
        <NavLink exact activeClassName="active_parent" to='/setting'>
        <div className={`bn_item`} onClick={()=>handleactive("setting")}>
            <Setting stroke="#707070" className={`bn_logo ${active=="setting"&&"active"}`}/>
            <span  className="bn_text">Setting</span>
        </div>
        </NavLink>
        <NavLink exact activeClassName="active_parent" to='/profile-update'>
        <div     className={`bn_item`} onClick={()=>handleactive("profile")}>
        <Profile stroke="#707070" className={`bn_logo ${active=="profile"&&"active"}`}/>
            <span  className="bn_text">Profile</span>
        </div>
        </NavLink>
    </div>
  )
}


export default BottomNav
