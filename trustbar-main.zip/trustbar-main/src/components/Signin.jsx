import {React,useState} from "react";
import logo from "../img/logo_mark.svg";
import { Link } from "react-router-dom";
import signArrow from "../img/signin.svg";
import "../css/Signin.css";
import Visibility from '../img/signinvisibility.svg'
import BottomNav from '../components/bottomNav';
export default function Signin() {
 
 const [ishidden,sethidden]=useState(true);
  return (
    <div className="signin_page">
      <div className="body_signin">
        <div className="header_signin">
          <div className="logo_signin">
            <img src={logo} alt="logo" />
          </div>
          <div className="heading_signin">
            <div className="mainheading_signin">Sign In To Account</div>
            <div className="subheading_signin">
              Sign in with username or email and password to use your account
            </div>
          </div>
        </div>
        <div className="signinInput_contianer">
          <div className="email_signin">
            <div className="email_input">
              <input
                type="text"
                id="mail"
                name="mail"
                placeholder="Username or email"
                className="input"
              />
            </div>
            <div className="email_border"></div>
            <Link to='/forget-password'>
            <div className="email_forget">Forget Password ?</div>
            </Link>
          </div>
          <div className="email_password">
            <div className="password_input">
              <input
                type={ishidden ?'password':'text'}
                id="password"
                name="password"
                placeholder="Password"
                className="input"
              />
              <div className='password_icon'>
              <img src={Visibility} alt='img' onClick={()=>sethidden(!ishidden)} />
            </div>
            </div>
            <div className="email_border"></div>
          </div>
        </div>
        <div className="signinBtn_container">
          <Link to="#">
            <div className="signin_btn">
              <span className="sbtn_info">Sign in</span>
              <span className="sbtn_logo">
                <img src={signArrow} alt="arrow" />
              </span>
            </div>
          </Link>
          <div className="dnt_signin">
            Don't have an account ? &nbsp; <Link to='/create-account'><span style={{color:'#024368',fontWeight:'600'}}>Sign up</span></Link>
          </div>
        </div>
      </div>
    </div>
  );
}
