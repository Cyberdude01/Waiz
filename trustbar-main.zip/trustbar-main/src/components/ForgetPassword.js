import React from 'react'
import '../css/ForgetPassword.css';
import Inpuut from './Inpuut';
import { Link } from 'react-router-dom';
import send from '../img/send.svg';

export default function ForgetPassword() {
    return (
        <div className='forget_page'>
            <div className='forget_header'>
                <div className="forget_heading">Forget Password</div>
                <div className="forget_subheading">Please enter your email address selected at registration</div>
            </div>
            <div className='forget_input'>
                <Inpuut name='email' type='text' placeholder='Email Address'/>
            </div>
            <div className="forget_btn">
            <Link style={{width:'100%'}} to='/'>
            <div className='forget_headerbtn'>
            
              <div className='forget_btninfo'>
                <span className='forget_infoheading'> <img style={{marginRight:'9px'}} src={send} className='forget_hblogo'/>Send</span>
              </div>
            </div>
            </Link>
            </div>
        </div>
    )
}
