import React from 'react'
import './Setting.css';
import SettingBoxes from './SettingBoxes';
import balance from '../../img/ac-balance.svg';
import activeIcon from '../../img/state.svg';
import CreateRefernce from '../../img/create-reference.svg';
import Notification from '../../img/notification.svg';
import Payout from '../../img/payout.svg';
import Email from '../../img/email-icon.svg';
import Help from '../../img/help-support.svg';
import Terms from '../../img/terms.svg';
import { Link } from 'react-router-dom';
import BottomNav from '../bottomNav';
export default function Setting() {
    return (
        <div className='setting_page'>
            <div className='setting_header'>
                App Settings
            </div>
            <div className='setting_body'>
                <div className='boxes_container'>
                    <SettingBoxes active={true} bimg={balance} aimg={activeIcon} info="Account Balance" />
                    <SettingBoxes active={true} bimg={CreateRefernce} aimg={activeIcon} info="Create Standard Reference" />
                    <SettingBoxes active={true} bimg={Notification} aimg={activeIcon} info="Get Notification" />
                    <SettingBoxes active={true} bimg={Payout} aimg={activeIcon} info="Pay Out" />
                    <SettingBoxes active={true} bimg={Email} aimg={activeIcon} info="Email Newsletters" />
                    <SettingBoxes active={false} bimg={Help} aimg={activeIcon} info="Help & Support" />
                    <SettingBoxes active={false} bimg={Terms} aimg={activeIcon} info="Terms & Conditions" />
                </div>
                <Link to='#'>
                    <div className='btn-container'>
                        <span className='btn_text'> Deactive My Account</span>
                    </div>
                </Link>
            </div>
          <BottomNav/>
        </div>
    )
}
