import React from 'react'
import './boxes.css';
import balance from '../../img/ac-balance.svg';
import activeIcon from '../../img/state.svg';
export default function SettingBoxes({active,info,bimg,aimg}) {
  return (
    <div className='box'>
      <div className='box_icon'>
          <img src={bimg} alt='img'/>
      </div>
      <div className='box_info'>
          {info}
      </div>
        {active?<div className='box_state'>
            <img src={aimg} alt='image'/>
        </div>:<div></div>}  
    </div>
  )
}
