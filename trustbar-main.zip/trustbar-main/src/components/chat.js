import React from 'react';
import { ChatEngine } from 'react-chat-engine';

export function Chat() {
	return (
		<ChatEngine
			projectID='f610c7ad-e4dd-4400-a593-f9948b9bacda'
			userName='adam'
			userSecret='2591c6e1-9202-4ad6-add2-066b10ce3a88'
		/>
	);
}