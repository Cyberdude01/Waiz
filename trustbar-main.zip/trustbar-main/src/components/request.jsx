import React, { Component } from "react";
import style1 from "../css/request.module.css";
import { MdKeyboardArrowLeft } from "react-icons/md";
import { FaCopy } from "react-icons/fa";
import logo from "../img/logo_mark.svg";
import Qr from "../img/mini_qr.svg";
import Mail from "../img/email.svg";
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Input from '@material-ui/core/Input';
import InputAdornment from '@material-ui/core/InputAdornment';
import AccountCircle from '@material-ui/icons/AccountCircle';
import { TextField } from "@material-ui/core";
import SettingsIcon from '@material-ui/icons/Settings';
import setting from '../img/standard.svg';
import SettingsApplicationsIcon from '@material-ui/icons/SettingsApplications';
import { Button } from "@material-ui/core";
import ArrowForwardIosIcon from '@material-ui/icons/ArrowForwardIos';
import arrow from '../img/arrow.svg'
import MailIcon from '@material-ui/icons/Mail';
import Topbar from './bottomNav';
import Borderbottom from "./borderbottom";
import { Link } from "react-router-dom";
import AttachMoneyIcon from '@material-ui/icons/AttachMoney';
import FileCopyIcon from '@material-ui/icons/FileCopy';
import amount from "../img/amount.svg";
import mail from '../img/email.svg'
import reference from "../img/reference.svg";
// import React, { Component } from "react";
// import style from "../css/request.module.css";


// import { FaDirections } from "react-icons/fa";
class Request extends Component {
  state = {};
  render() {
      const icon = <AccountCircle />;
      const copy=<img src=''/>
    return (
      <div>
        
        <div className={style1.requestMain}>
            <div className={style1.requestlogo}>
              <div className={style1.headerlogo}>
                <img src={logo} alt="logo" />
              </div>
              <div className={style1.requestheading}>Request Payment
             <div className={style1.requestsubheading}>Please select a request type</div>
            </div>
            </div>
           <div className={style1.cinputWrapper}>
            <div className={style1.inputWrapper}>
              <form>
              <div className={style1.inputBox}>
                <img style={{width:'11px',height:'14px'}} src={reference} />
                <span className={style1.inputWrap}><input
                    type="text"
                    id="fname"
                    name="fname"
                    placeholder=" Reference" 
                    className={style1.cinput}
                /></span>
              </div>
              </form>
            </div>
            <div className={style1.standard}>
              <span className={style1.standardfont}>
                <img style={{height:'16px',width:'16px'}} src={setting} alt="setting"/> Use Standard Reference
              </span>
            </div>
            <div className={style1.inputWrapperbottom}>
            <div className={style1.inputBoxBottom}>
                <img src={amount} />
                <span className={style1.inputWrap}>
                <input
                    type="text"
                    id="fname"
                    name="fname"
                    placeholder=" Amount" 
                    className={style1.cinput}
                /></span>
              </div>
            </div>
            </div>
            <div className={style1.bottombtn1}>
            <Link style={{width:'100%'}} to='scan-to-pay'>
            <div className={style1.headerbtn}>
            <div className={style1.btnlogo}>
                  <img style={{width:'10vw'}} src={Qr} className={style1.hblogo}/>
              </div>
              <div className={style1.btninfo}>
                <span className={style1.infoheading}>Generate a QR code</span>
                <span className={style1.infodesc}>Generate & display QR code</span>
              </div>
              <div className={style1.btnarrow}><img src={arrow} className={style1.hblogo}/></div>
            </div>
            </Link>
            
            <Link style={{width:'100%', marginTop:'100px'}} to='send2'>
            <div className={style1.headerbtn2}>
            <div className={style1.btnlogo}>
                  <img style={{width:'10vw'}} src={mail} className={style1.hblogo}/>
              </div>
              <div className={style1.btninfo}>
                <span className={style1.infoheading}>Send Payment request SMS</span>
                <span className={style1.infodesc}>Send an sms to the person you are<br/> requesting money from</span>
              </div>
              <div className={style1.btnarrow}><img src={arrow} className={style1.hblogo}/></div>
            </div>
            </Link>
            </div>
          </div>
          <Topbar/>
      </div>
    );
  }
}

export default Request;
