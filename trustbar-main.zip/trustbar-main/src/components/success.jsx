import React, { Component } from "react";
import { Modal, Button } from "antd";
// import style from "../css/success.module.css";
import style from "../css/scantopay.module.css";
import { MdKeyboardArrowLeft } from "react-icons/md";
import { AiFillPicture } from "react-icons/ai";
import { TiTick } from "react-icons/ti";
import logo from "../img/logo_mark.svg";
import tick from "../img/tick.png";
import qrcode from "../img/success.png";
import { Link } from "react-router-dom";
import Borderbottom from "./borderbottom";
import Topbar from './bottomNav'
class Success extends Component {
  constructor(props) {
    super(props);
    this.state = {
      IsModalVisible: false,
    };
  }

  render() {
    const showModal = () => {
      this.setState({
        IsModalVisible: true,
      });
    };
    const handleOk = () => {
      this.setState({
        IsModalVisible: false,
      });
    };

    const handleCancel = () => {
      this.setState({
        IsModalVisible: false,
      });
    };
    return (
      <div>
        <div className={style.scanMain}>
          {/* <button className={style.successb}>Success</button>
          <button className={style.successb}>My Balance</button>
          <div className={style.imgbu}>
            <div style={{ display: "flex" }}>
              <AiFillPicture size="25px" />
              <div className={style.prof}>
                <span> Mark Smith</span>
                <span>26 Oct 21 11:13</span>
              </div>
            </div>
          </div>
          <div className={style.tickmain}>
            <div className={style.tick}>
              <TiTick />
            </div>
          </div>
          <div className={style.successEnd}>
            <div class="d-flex">
              <button className={style.successb}>Play again</button>

              <button className={style.successb} onClick={showModal}>
                Done
              </button>
            </div>
          </div>

          <Modal
            visible={this.state.IsModalVisible}
            onOk={handleOk}
            onCancel={handleCancel}
            className={style.antmodal}
            footer={false}
            closable={false}
          >
            <div className={style.modalmain}>Unsuccessful</div>
            <div
              style={{
                fontSize: "14px",
                fontWeight: "500",
                textAlign: "center",
              }}
            >
              mobile efro unsuccesfully widded
            </div>
            <hr />
            <div className="d-flex">
              <button
                className={style.modalbb}
                style={{ borderRight: "2px solid black" }}
              >
                Try Again
              </button>
              <button className={style.modalbb}>Cancel</button>
            </div>
          </Modal> */}
          {/* <Link to="/">
            <MdKeyboardArrowLeft
              style={{ marginLeft: "-7px", color: 'rgba(38, 38, 38, 0.8)' }}
            />
          </Link> */}
          <div className={style.logo}>
            <img src={logo} alt="logo" />
            </div>
            <div className={style.heading}>
            Payment Successful
            </div>
            <div className={style.tick}>
            <img src={tick} alt="" />
          </div>
          <div className={style.qrco}>
            <img src={qrcode} alt="" />
          </div>
          <Topbar/>
        
        </div>
      </div>
    );
  }
}

export default Success;
