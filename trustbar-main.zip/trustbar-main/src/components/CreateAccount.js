import React from 'react'
import '../css/CreateAccount.css'
import Inpuut from './Inpuut'
import checkbox from '../img/checkbox.svg';
import { Link } from 'react-router-dom';
import createArrow from "../img/createarrow.svg";
import BottomNav from './bottomNav';

export default function CreateAccount() {
  return (
    <div className='create_page'>
      <div className='create_header'>
          <div className='welcome_header'>
              Welcome !
          </div>
          <div className='sub_header'>
              Please provide following details for your new account
          </div>
      </div>
      <div style={{width:'100%'}}>
          <Inpuut name='fname' type='text' placeholder='First Name'/>
          <Inpuut name='lname' type='text' placeholder='Last Name'/>
          <Inpuut name='email' type='email' placeholder='Email Address'/>
          <Inpuut name='number' type='number' placeholder='Mobile Number'/>
          <Inpuut name='country' type='text' placeholder='Country'/>
          <Inpuut name='password' type='password' placeholder='Password'/>
          <Inpuut name='cpassword' type='password' placeholder='Confirm Password'/>
      </div>
      <div className='check_box'>
          <span className='checkbox_icon'><img src={checkbox} alt='img'/></span>
          <span className='checkbox_text'>lorem ipsum is simply dummy text of the printing and typesetting industry.</span>
      </div>
      <div className='signup_btn'>
      <Link to="/">
            <div className="create_btn">
              <span className="cbtn_logo">
                <img src={createArrow} alt="img" />
              </span>
              <span className="cbtn_info">Sign up my account</span>
            </div>
          </Link>
          <div className="dnt_signin">
            Don't have an account ? &nbsp;<Link to='/signin-account'><span style={{color:'#024368',fontWeight:'600'}}>Sign in</span></Link>
          </div>
      </div>
    </div>
  )
}
