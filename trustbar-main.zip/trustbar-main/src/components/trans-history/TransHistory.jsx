import React from 'react';
import TransData from '../trans-data/TransData';
import "./TransHistory.css"

const TransHistory = () => {
  return (
    <div className="trans_history">
      <span className="trans_heading">Tarnsaction History</span>
      <div className="trans_box">
          <TransData
           name="John Smith"
            type="loading"
            price="123" 
            date="10 Oct 2020"
            item="Driver"
            />
            <TransData
           name="Robert"
            type="cross"
            price="123"
            date="10 Oct 2020"
            item="Driver"
            />
            <TransData
           name="Jane Doe"
            type="tick"
            price="123"
            date="10 Oct 2020"
            item="Driver"
            />
      </div>
    </div>
  )
}

export default TransHistory
