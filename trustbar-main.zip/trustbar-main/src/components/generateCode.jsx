import React, { Component } from "react";
// import style from "../css/generatecode.module.css";
// import req from "../css/request.module.css";
import style from "../css/send.module.css";
import style1 from "../css/generatecode.module.css";
import { IoShareOutline } from "react-icons/io5";
import scan from "../css/scantopay.module.css";
import qrcode from "../img/qrcode.svg";
import succ from "../css/success.module.css";
import mail from '../img/email.svg';
// import { Modal, Button } from "antd";
import { AiFillPicture } from "react-icons/ai";
import SettingsApplicationsIcon from '@material-ui/icons/SettingsApplications';
import { Button } from "@material-ui/core";
import logo from "../img/logo_mark.svg";
import Qr from "../img/mini_qr.svg";
import arrow from '../img/arrow.svg'
import Mail from "../img/email.svg";
import { MdKeyboardArrowLeft } from "react-icons/md";
import ArrowForwardIosIcon from '@material-ui/icons/ArrowForwardIos';
import MailIcon from '@material-ui/icons/Mail';
import { Link } from "react-router-dom";
import { Divider } from "@material-ui/core";
import Borderbottom from "./borderbottom";
import Topbar from './bottomNav'
class GenerateCode extends Component {
  constructor(props) {
    super(props);
    this.state = {
      IsModalVisible: false,
    };
  }
  render() {
    const showModal = () => {
      this.setState({
        IsModalVisible: true,
      });
    };
    const handleOk = () => {
      this.setState({
        IsModalVisible: false,
      });
    };

    const handleCancel = () => {
      this.setState({
        IsModalVisible: false,
      });
    };
    const send = () => {
      console.log("send");
      window.location.href =
        "mailto:user@example.com?subject=for testing&body= weed 3 re\nmessage%20goes%20here";
    };
    return (
      
      
    
          <div className={style1.scanMain}>
           
            <div className={style1.logogenerate}>
            <img src={logo} alt="logo" />
            <div className={style1.heading}>Pay
            <br/>
             <span className={style1.subheading}>Please select a request type</span>
            </div>
            <div style={{width:'100%',border: '1px solid #DADADA',marginTop:'14px'}} ></div>
            </div>
            
          <div className={style1.btncontainer}>
            <div className={style1.bottombtn1}>
            <Link style={{width:'100%'}} to='scan-to-pay'>
            <div className={style1.headerbtn}>
            <div className={style1.btnlogo}>
                  <img style={{width:'31px',height:'31px'}} src={Qr} className={style1.hblogo}/>
              </div>
              <div className={style1.btninfo}>
                <span className={style1.infoheading}>Scan To Pay</span>
                <span className={style1.infodesc}>Generate & display QR code</span>
              </div>
              <div className={style1.btnarrow}><img src={arrow} className={style1.hblogo}/></div>
            </div>
            </Link>
            </div>
            <div className={style1.bottombtn2}>
            <Link style={{width:'100%'}} to='/send2'>
            <div className={style1.headerbtn}>
            <div className={style1.btnlogo}>
                  <img style={{width:'31px',height:'31px'}} src={mail} className={style1.hblogo}/>
              </div>
              <div className={style1.btninfo}>
                <span className={style1.infoheading}>Send Payments</span>
                <span className={style1.infodesc}>Send an sms to the person you are <br/> requesting money from</span>
              </div>
              <div className={style1.btnarrow}><img src={arrow} className={style1.hblogo}/></div>
            </div>
            </Link>
            </div>
            </div>
            <Topbar/>
          </div>
    );
  }
}

export default GenerateCode;
