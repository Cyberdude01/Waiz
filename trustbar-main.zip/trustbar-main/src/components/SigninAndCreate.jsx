import React from "react";
import "../css/SigninAndCreate.css";
import logo from "../img/logo_mark.svg";
import signArrow from "../img/signin.svg";
import createArrow from "../img/createarrow.svg";
import BottomNav from "./bottomNav";
import { Link } from "react-router-dom";
export default function SigninAndCreate() {
  return (
    <div className="sign_and_createpage">
      <div className="body">
        <div className="header">
          <div className="header_logo">
            <img src={logo} alt="logo" />
          </div>
          <div className="header_heading">
            <span className="header_heading_font">TrustBar</span>
          </div>
        </div>
        <div className="btn_container">
          <Link to="/signin-account">
            <div className="signin_btn">
              <span className="sbtn_info">Sign in</span>
              <span className="sbtn_logo">
                <img src={signArrow} alt="arrow" />
              </span>
            </div>
          </Link>
          <Link to="/create-account">
            <div className="create_btn">
              <span className="cbtn_logo">
                <img src={createArrow} alt="img" />
              </span>
              <span className="cbtn_info">Create an Account</span>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}
