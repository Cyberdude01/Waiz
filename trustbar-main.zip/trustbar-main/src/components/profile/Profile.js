import React from 'react'
import './Profile.css';
import Pic from '../../img/profile-pic.svg';
import update from '../../img/update-icon.svg';
import Inpuut from '../Inpuut';
import '../../css/Input.css';
import { Link } from 'react-router-dom';
import BottomNav from '../bottomNav';
export default function Profile({ name }) {
    return (
        <div className='profile_page'>
            <div className="profile_header">
                <div className='p_heading'>Profile</div>
                <div className="p_data">
                    <div className="data_pic">
                        <img src={Pic} alt='img' />
                    </div>
                    <div className='data_desc'>
                        <div className='desc_name'>
                            <div className='name'>
                                Andrew
                            </div>
                            <div className='flatcher'>
                                <span>Flatcher</span>
                            </div>
                        </div>
                        <div className='desc_info'>
                            Lorem ipsum is simply dummy text of the printing
                            and typesetting industry.
                        </div>
                        <div className='desc_score'>
                            Credit Score : $25,00
                        </div>
                        <div className='p_brdr'>
                            <div className='blue'></div>
                            <div className='gray'></div>
                        </div>
                    </div>
                </div>
            </div>
            <div className='profile_body'>
                <div className='profile_input'>
                    <Inpuut name='fname' type='text' placeholder="First Name" />
                    <Inpuut name='lname' type='text' placeholder="Last Name" />
                    <Inpuut name='mail' type='mail' placeholder="Email Address" />
                    <Inpuut name='number' type='number' placeholder="Mobile Number" />
                    <Inpuut name='country' type='text' placeholder="Country" />
                    <Inpuut name='password' type='password' placeholder="Password" />
                    <Inpuut name='dob' type='text' placeholder="Date of birth" />
                </div>
                <div className='profile_btn'>
                    <Link style={{ width: '100%' }} to='/'>
                        <div className='forget_headerbtn'>

                            <div className='forget_btninfo'>
                                <span className='forget_infoheading'> <img style={{ marginRight: '9px' }} src={update} className='forget_hblogo' />Add Card</span>
                            </div>
                        </div>
                    </Link>
                </div>
            </div>
            <BottomNav/>
        </div>
    )
}
