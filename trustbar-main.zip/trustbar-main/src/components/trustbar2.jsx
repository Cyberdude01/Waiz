import React, { Component } from "react";
// import style from "../css/send.module.css";
import style from "../css/trustbar2.module.css";
import { MdKeyboardArrowLeft } from "react-icons/md";
import { FaCopy } from "react-icons/fa";
import qrcodeop from "../img/download.png";
import { Link, useHistory } from "react-router-dom";
import copy from '../img/copy.svg';
import { Button } from "@material-ui/core";
import FileCopyIcon from '@material-ui/icons/FileCopy';
import Borderbottom from "./borderbottom";
import arrow from '../img/sendtoarrow.svg';
import send from '../img/send.svg';
import Topbar from './bottomNav'
function Send2() {
  let history = useHistory();
  const goToPreviousPath = () => {
    history.goBack();
  };
  return (
      <div className={style.scanMain}>
       
          <div className={style.sendto}> 
           <span style={{position:'fixed',left:'18px'}}> <Link to='/request'><img style={{width:'13px',height:'26px'}} src={arrow}/></Link></span>
          Send to Address
          </div>
          <div className={style.formcontainer} >
            
              <form>
            <div className={style.inputWrapper}>
              <div className={style.inputbox}>
              <input
                  type="text"
                  id="fname"
                  name="fname"
                  placeholder="To Address"
                  className={style.cinput}
                />
                </div>
              </div>
              <div className={style.inputbox2}>
              <div className={style.inputWrapper}>
                <input
                  type="text"
                  id="fname"
                  name="fname"
                  placeholder="Send Amount"
                  className={style.cinput}
                />
                </div>
                </div>
                <div className={style.inputbox2}>  
                <div className={style.inputWrapper}>           
                <input
                  type="text"
                  id="fname"
                  name="fname"
                  placeholder="Message"
                  className={style.cinput}
                />
                </div>
                </div>
                
              </form>
              <div className={style.btncontainer}>
             <a><img src={copy}/> &nbsp; <span className={style.filecopy}>Copy</span></a>
           </div>
            </div>
          
           
          <Link style={{width:'100%'}} to='/transfer-successfull'>
            <div className={style.headerbtn}>
            
              <div className={style.btninfo}>
                <span className={style.infoheading}> <img style={{marginRight:'9px'}} src={send} className={style.hblogo}/>Send</span>
              </div>
            </div>
            </Link>
          
       
        <Topbar/>
      </div>
  );
}

export default Send2;
