import React, { Component } from "react";
import style from "../css/send.module.css";
import style1 from "../css/scantopay.module.css";
import { MdKeyboardArrowLeft } from "react-icons/md";
import { FaCopy } from "react-icons/fa";
import { Link } from "react-router-dom";
class Send1 extends Component {
  state = {};
  render() {
    return (
      <div>
        <div className={style.main}>
          <div className={style.sendMain}>
            <MdKeyboardArrowLeft
              style={{ marginLeft: "-7px", color:'rgba(38, 38, 38, 0.8)' }}
            />
            <div className={style1.heading}>Send to Address</div>
            <div>
              <form>
                <label for="fname" style={{ color: "#fbfbfb" }}>
                  To Address
                </label>
                <input type="text" id="fname" name="fname" placeholder="0x" />
                <label for="fname" style={{ color: "#fbfbfb" }}>
                  Send Amount
                </label>
                <input
                  type="text"
                  id="fname"
                  name="fname"
                  placeholder="R 0.00"
                />
                <label for="fname" style={{ color: "#fbfbfb" }}>
                  Message
                </label>
                <input
                  type="text"
                  id="fname"
                  name="fname"
                  className={style.placs}
                  placeholder="Optional unenctypted message"
                />
              </form>
            </div>
            <div
              style={{
                marginTop: "20px",
                marginBottom: "-11px",
                color: "white",
              }}
            >
              Copy
            </div>
            <FaCopy color="#02AE98" style={{ marginTop: "20px" }} />
          </div>
          <Link to="request">
            <div>
              <button className={style1.button}> Send</button>
            </div>
          </Link>
        </div>
      </div>
    );
  }
}

export default Send1;
