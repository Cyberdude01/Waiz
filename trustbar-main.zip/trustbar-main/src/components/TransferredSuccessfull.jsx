import React from "react";
import "../css/TransferredSuccessfull.css";
import Transfer from "../img/transfer.svg";
import { Link } from "react-router-dom";
import BottomNav from "./bottomNav";
export default function TransferredSuccessfull() {
  return (
    <div className="tranfser_page">
      <div className="transfer_header">
        <div className="transfer_logo">
          <img src={Transfer} alt="img" />
        </div>
        <div className="transfer_heading">
          <div className="heading_main">Transferred Successfully</div>
          <div className="heading_upper">
            Dear user your amount has been transferred to your requested
            receipt.
          </div>
          <div className="heading_border"></div>
          <div className="heading_lower">Thank you for using our service</div>
        </div>
      </div>
      <div className="transfer_btncontainer">
        <Link to="#">
          <div className="view_btn">
              View Details
          </div>
        </Link>
        <div className='btn_divider'></div>
        <Link to="#">
          <div className="continue_btn">
              Continue
          </div>
        </Link>
      </div>
      <BottomNav/>
    </div>
  );
}
