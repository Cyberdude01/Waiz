import React, { Component } from "react";
import { Link } from "react-router-dom";
import style from "../css/scantorequest.module.css";
// import qrcodeimg from "../img/img.png"
import logo from "../img/logo_mark.svg";
import qrcode from "../img/requestqr.svg";

import FullHeight from "react-full-height";
import { MdKeyboardArrowLeft } from "react-icons/md";
import { FaCopy } from "react-icons/fa";
import Borderbottom from "./borderbottom";
import Topbar from './bottomNav';
class ScanToRequest extends Component {
  state = {};
  render() {
    const send = () => {
      console.log("send");
      window.location.href =
        "sms://+14035550185?body=I%27m%20interested%20in%20your%20product.%20Please%20contact%20me";
    };
    return (
      
        <div className={style.scanMain}>
          {/* <Link to="/">
            <MdKeyboardArrowLeft
              style={{ marginLeft: "-7px", color: 'rgba(38, 38, 38, 0.8)' }}
            />
          </Link> */}
          <div className={style.logo}>
            <img src={logo} alt="logo" />
            <div className={style.heading}>Scan to Pay
            <br/>
             <span className={style.subheading}>Please select a request type</span>
            </div>
            </div>
            
          <div className={style.qrco}>
            <img src={qrcode} alt="" />
            <div className={style.qrcofont}>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Maiores veritatis 
            </div>
          </div>   
                
         <Topbar/>
      
        </div>
    );
  }
}

export default ScanToRequest;
