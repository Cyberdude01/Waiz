import React from 'react'
import '../css/Input.css'
export default function Inpuut({type,placeholder,name}) {
  return (

      <div className="container">
            <div className="input_wrap">
              <input
                type={type}
                id={name}
                name={name}
                placeholder={placeholder}
                className="input"
              />
            </div>
            <div className="bottom_border"></div>
          </div>
    
  )
}
