import React, { Component } from "react";
import { Link } from "react-router-dom";
import style from "../css/scantopay.module.css";
import FullHeight from "react-full-height";
import { MdKeyboardArrowLeft } from "react-icons/md";
import logo from "../img/logo_mark.svg";
import qrcode from "../img/qrcode.svg";
import Topbar from './bottomNav';

class Scantopay extends Component {
  state = {};
  render() {
    return (
        <div className={style.scanMain}>
          {/* <button className={style.scanb}>Photos</button>
          <Link to="/success">
            <div className={style.qrdcodepic}>
              <img src={qrcode} width="70%" />
            </div>
          </Link> */}
          {/* <Link to="/">
            {" "}
            <MdKeyboardArrowLeft color="white" style={{ marginLeft: "-7px",color:'rgba(38, 38, 38, 0.8)',fontSize:'10px', }} />
          </Link> */}

          <div className={style.logo}>
            <img src={logo} alt="logo" />
            <div className={style.heading}>Request Payment
            <br/>
             <span className={style.subheading}>Please select a request type</span>
            </div>
          </div>
            
            <div className={style.qrco}>
              <span className={style.qrinfo}>Scan QR Code</span>
            <img src={qrcode} alt="" />
          </div>
            <Topbar/>
          </div>
    );
  }
}

export default Scantopay;
