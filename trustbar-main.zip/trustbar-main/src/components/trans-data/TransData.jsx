import React from 'react';
import "./TransData.css";
import tick from "../../img/bluetick.svg"
import loading from "../../img/loading.svg"
import cross from "../../img/cross.svg"

const TransData = ({name,item,type,price,date}) => {
  return (
    <div className="trans_data">
      <div className="trans_logo">
        <img src={type =="loading"?loading:type=="tick"?tick:cross} />
      </div>
      <div className="trans_info">
          <span className="info_name">{name}</span>
          <span className="info_item">{item}</span>
      </div>
      <div className="trans_right">
          <span className="t_price" style={{color:type =="loading"?"#262626":type=="tick"?"#00D563":"#FF3131"}}>R{price}</span>
          <span className="t_date">{date}</span>
      </div>
    </div>
  )
}

export default TransData
